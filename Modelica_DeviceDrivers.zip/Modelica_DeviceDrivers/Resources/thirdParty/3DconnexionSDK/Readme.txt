3Dconnexion Software Developer Kit for Linux

*THE C FILES IN THIS FOLDER MAY NOT BE DISTRIBUTED!*

Please download the SDK from 3DCONNEXION and put the two files
- xdrvlib.c
- xdrvlib.h
into the current directory.

Licensing conditions of 3Dconnexion (http://www.3dconnexion.com/) seem to allow to distribute binaries generated from the driver libary, but not the source (available in this folder). See the 3dconnexion license conditions in "3DCONNEXION_SDK_licence-agreement.htm".
