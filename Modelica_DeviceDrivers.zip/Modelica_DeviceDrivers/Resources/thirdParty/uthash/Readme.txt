uthash - Hash table implementation (http://troydhanson.github.io/uthash/)
