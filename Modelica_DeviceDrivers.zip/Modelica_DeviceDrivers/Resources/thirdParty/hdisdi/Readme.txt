Files from the Windows Driver Kit 7.1.0 (WDK)

*THE DEVELOPMENT FILES IN THIS FOLDER MAY NOT BE DISTRIBUTED!*

The needed files are freely available from Microsoft, however the
corresponding license sets limits on the distributability of the
files. Consequently, the files are not distributed with this library.

Please download the WDK 7.1.0 from the following address:

http://www.microsoft.com/en-us/download/details.aspx?id=11800

Install it on your computer search for files given below within the
installation directory of the WDK and copy them into the directory of this Readme.txt,
so that you end up with following directory tree:

./hidpi.h
./hidsdi.h
./hidusage.h
./amd64/hid.lib
./amd64/setupapi.lib
./i386/hid.lib
./i386/setupapi.lib

Double check that you copied the libraries from the correct architecture dependent folders.




