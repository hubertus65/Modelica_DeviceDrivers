Include files used through Modelica's external function interface should go
into this directory.

Include files in this folder provide access to device drivers through Modelica's
external function interface. Most headers are in fact header-only libraries.
