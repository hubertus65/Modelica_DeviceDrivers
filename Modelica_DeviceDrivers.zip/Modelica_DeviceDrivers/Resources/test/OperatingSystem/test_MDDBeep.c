#include "../../Include/MDDBeep.h"

int main(void) {
  return MDD_beep(500, 1);
}
