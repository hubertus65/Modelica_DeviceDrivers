Tests for the ../src/InputDevices module
