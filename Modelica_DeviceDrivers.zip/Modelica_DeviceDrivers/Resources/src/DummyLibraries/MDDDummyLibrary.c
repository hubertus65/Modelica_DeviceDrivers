/** Dummy library for uniform treatment of Modelica external function in windows and linux.
 *
 * @file
 * @author		bernhard-thiele
 * @since		2019-04-05
 * @copyright see accompanying file LICENSE_Modelica_DeviceDrivers.txt
 *
 * See README.md for the rationale behind this approach.
*/

static void MDD_dummy(void);
