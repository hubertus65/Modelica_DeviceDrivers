/** Wrapping header-only library MDDMQTT.h into a DLL.
 *
 * @file
 * @author		tbeu
 * @since		2018-08-23
 * @copyright see accompanying file LICENSE_Modelica_DeviceDrivers.txt
*/

#define ITI_MDD
#define MDDSHAREDLIBRARY
#include "../../Include/MDDMQTT.h"
