/** Wrapping header-only library MDDSoftingCAN.h into a DLL.
 *
 * @file
 * @author		bernhard-thiele
 * @since		2014-04-12
 * @copyright see accompanying file LICENSE_Modelica_DeviceDrivers.txt
*/

#define MDDSOFTINGCANUSECMAKE
#define ITI_MDD
#define MDDSHAREDLIBRARY
#include "../../Include/MDDSoftingCAN.h"
