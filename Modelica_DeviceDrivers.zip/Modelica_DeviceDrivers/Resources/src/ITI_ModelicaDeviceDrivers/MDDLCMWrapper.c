/** Wrapping header-only library MDDLCM.h into a DLL.
 *
 * @file
 * @author		tbeu
 * @since		2016-05-05
 * @copyright see accompanying file LICENSE_Modelica_DeviceDrivers.txt
*/

#define ITI_MDD
#define MDDSHAREDLIBRARY
#include "../../Include/MDDLCM.h"
