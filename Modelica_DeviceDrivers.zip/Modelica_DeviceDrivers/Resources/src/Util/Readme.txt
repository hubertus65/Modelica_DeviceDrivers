Some utility classes used across the project

